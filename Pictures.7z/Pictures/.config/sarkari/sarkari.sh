#!/bin/bash

printf  "\n\033[1;31mDownloading the Data from Sarkari Result website\033[0m\n\n"

rm ~/.config/sarkari/old.html
mv ~/.config/sarkari/new.html ~/.config/sarkari/old.html

wget -nv --show-progress --progress=dot -O ~/.config/sarkari/index.html https://sarkariresult.com/
sleep 2s

printf  "\n\n\033[1;31mDownload Complete\033[0m\n\n"

cat ~/.config/sarkari/index.html | grep \<li\> | cut -d\> -f3 | cut -d\< -f1 > ~/.config/sarkari/new.html

date >> ~/.config/sarkari/new.html

printf  "\n\n\033[1;31m..............Comparing the Older and New Data for any Differences..............\033[0m\n\n"

colordiff -y -w ~/.config/sarkari/old.html ~/.config/sarkari/new.html

